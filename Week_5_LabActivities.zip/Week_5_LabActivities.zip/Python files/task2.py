from recursion_mergesort import *

data_sizes = [6, 9, 12]

# Testing Merge Sort

for data_size in data_sizes:
    random_list = [random.randint(1, 1000) for _ in range(data_size)]
    print(f"Using merge sort to sort '{random_list}'")
    print(f"Result:                   {merge_sort(random_list)}\n")


data_sizes = [6, 9, 12]

# Testing insertion sort
for data_size in data_sizes:
    random_list = [random.randint(1, 1000) for _ in range(data_size)]
    print(f"Using insertion sort to sort '{random_list}'")
    print(f"Result:                       {insertion_sort(random_list)}\n")


# Benchmarking the two algorithms

data_sizes = [100, 1_000, 10_000, 100_000]

# run each test 10 times to obtain better average.

for data_size in data_sizes:
    random_list = [random.randint(1, 1000) for _ in range(data_size)]
    
    merge_sort_time = timeit.timeit(lambda: merge_sort(random_list), number=10)/10
    insertion_sort_time = timeit.timeit(lambda: insertion_sort(random_list), number=10)/10
    
    print(f"Merge sort @ data_size of {data_size}:     {merge_sort_time:.6f} seconds")
    print(f"Insertion sort @ data_size of {data_size}: {insertion_sort_time:.6f} seconds\n")
    

