
# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower

total_moves = 1 # account for final move
def moveDisks(n, fromTower, toTower, auxTower):
    global total_moves

    if n == 1: # Stopping condition
        #print("Move disk", n, "from", fromTower, "to", toTower)
        
        return   
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        #print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)
        total_moves += 2

def main():
    n = eval(input("Enter number of disks: "))
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print(f"Number of moves is {total_moves}")

main() # Call the main function


