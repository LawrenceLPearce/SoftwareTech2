import timeit

# copy paste recursion examples

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Example usage:
#result = sum_of_natural_numbers(5)  # Calculates 1 + 2 + 3 + 4 + 5
#print(f"The sum of the first 5 natural numbers is {result}")


# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case


# Example usage:
#result = fibonacci(10)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
#print(f"The 7th Fibonacci number is {result}")


# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Example usage:
#num = 5
#result = factorial(num)
#print(f"The factorial of {num} is {result}")



# Iterative approach:

def sum_of_natural_numbers_iter(n):
    total = 0
    for i in range(n):
        total += i
    return total

def fibonacci_iter(n):
    last_num = 0
    current_num = 1
    for _ in range(n-1):
        
        last_num, current_num = current_num, last_num + current_num
    
    return current_num

print(fibonacci_iter(7))

def factorial_iter(n):
    total = 1
    
    while n > 1:
        total = total * n
        n -= 1

    return total

print(factorial_iter(5))


# timeit
#

if __name__ == "__main__":
    
    # run tests at all these sizes.
    data_sizes = [10, 20, 40]

    for size in data_sizes:

    # Sum tests
        sum_rec_time = timeit.timeit(lambda: sum_of_natural_numbers(size), number=10)/10
        sum_iter_time = timeit.timeit(lambda: sum_of_natural_numbers_iter(size), number=10)/10

        print(f"Recursive Sum took {sum_rec_time:.6f} seconds @ size {size}")
        print(f"    Iterative Sum took {sum_iter_time:.6f} seconds @ size {size}")

    print("\n")
    for size in data_sizes:
#    Fibonachi tests.
        fib_rec_time = timeit.timeit(lambda: fibonacci(size), number=10)/10
        fib_iter_time = timeit.timeit(lambda: fibonacci_iter(size), number=10)/10

        print(f"Recursive Fibonachi took {fib_rec_time:.6f} seconds  @ size {size}")
        print(f"    Iterative Fibonachi took {fib_iter_time:.6f} seconds  @ size {size}")

    print("\n")
    for size in data_sizes:
# Factorial tests
        fact_rec_time = timeit.timeit(lambda: factorial(size), number=10)/10
        fact_iter_time = timeit.timeit(lambda: factorial_iter(size), number=10)/10
    
        print(f"Recursive Factorial took {fact_rec_time:6f} seconds @ size {size}")
        print(f"    Iterative Factorial took {fact_iter_time:6f} seconds @ size {size}")

# 

