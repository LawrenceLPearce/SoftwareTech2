from tkinter import * # Import tkinter
from math import sqrt
class KochSnowflake:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Koch Snowflake") # Set a title
        self.width = 400
        self.height = 400
        self.canvas = Canvas(window,
                             width = 400, height = 500)
        self.canvas.pack()
        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()
        Label(frame1,
              text = "Enter an order: ").pack(side = LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable = self.order,justify = RIGHT).pack(side = LEFT)
        Button(frame1, text = "Display Koch Snowflake ", command = self.display).pack(side = LEFT)
        window.mainloop() # Create an event loop


    def display(self):
        self.canvas.delete("line")
        p1 = [self.width / 2, 20]
        p2 = [20, self.height - 20]
        p3 = [self.width - 20, self.height - 20]
        order = int(self.order.get())
        self.display_edge(order, p1, p3)
        self.display_edge(order, p3, p2)
        self.display_edge(order, p2, p1)


    
    def display_edge(self, order, p1, p2):
        if order == 0: # Base condition
            # Draw a line to connect the points.
            self.drawLine(p1, p2)        
        else:
            # fractal the line itself.
            # devide line into three, the middle third becomes a new sub-fractal
            p_a, p_b = self.third_points(p1, p2)   # 1/3 and 2/3 points
            peak = self.triangle_coords(p_a, p_b)   # outward bump tip
            self.display_edge(order - 1, p1,   p_a) # first 3rd of the edge.
            self.display_edge(order - 1, p_a,  peak) # left side of small triangle ( to the peak)
            self.display_edge(order - 1, peak, p_b) # right side of small triangle (to peak)
            self.display_edge(order - 1, p_b,  p2) # last 3rd of edge


    def drawLine(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags = "line")
    # Return the midpoint between two points
    #
    def third_points(self, p1, p2):
        # divides a line in 3 and returns the two points.
        r1 = 2 * [0]    # resultant point 1 and 2
        r2 = 2 * [0]

        r1[0] = p1[0] + (p2[0] - p1[0]) / 3 #r1 x
        r1[1] = p1[1] + (p2[1] - p1[1]) /3 #r1 y

        r2[0] = p1[0] + 2 * (p2[0] - p1[0]) / 3 #r1 x
        r2[1] = p1[1] + 2 * (p2[1] - p1[1]) /3 #r1 y

        return r1, r2


    def triangle_coords(self, p1:tuple, p2:tuple):
        # return the third point of an equalateral triangle given first 2 points

        midpoint = self.midpoint(p1, p2)
        x = midpoint[0] - (sqrt(3)/2)*(p1[1]-p2[1])
        y = midpoint[1] + (sqrt(3)/2)*(p1[0]-p2[0])
        return (x, y)

    def midpoint(self, p1, p2):
        p = 2 * [0]
        p[0] = (p1[0] + p2[0]) / 2
        p[1] = (p1[1] + p2[1]) / 2
        return p

KochSnowflake() # Create GUI

