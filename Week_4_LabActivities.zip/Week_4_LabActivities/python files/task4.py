import timeit
import random

def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i
        
    return -1

def binary_search(array, target):

    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1

def bubble_sort(arr):
    """
    Bubble Sort: A simple sorting algorithm that repeatedly steps through the list,
    compares adjacent elements, and swaps them if they are in the wrong order.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):

            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break

    return arr

def insertion_sort(arr):
    """
    Insertion Sort: A simple sorting algorithm that builds the final sorted
    array one item at a time. It takes each element from the input list and
    inserts it into its correct position in the sorted part of the array.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr

# challenge no.1: insertion_sort + linear_search
def linear_search_insertion_sorted(array, target):
    array = insertion_sort(array)
    result = linear_search(array, target)
    return result

# challenge no. 2: bubble_sort + linear_search
def linear_search_bubble_sorted(array, target):
    array = bubble_sort(array)
    result = linear_search(array, target)
    return result


# challenge no.3: insertion_sort + binary_search.
def binary_search_insertion_sorted(array, target):
    array = insertion_sort(array)
    result = binary_search(array, target)
    return result

# challenge no. 4: bubble_sort + binary_search
def binary_search_bubble_sorted(array, target):
    array = bubble_sort(array)
    result = binary_search(array, target)
    return result


"""
individual testing is belong. see furthure down for code to run multiple averaged tests.
unsorted_list = [random.randint(1, 1000) for n in range(10000)]


target = random.randint(1, 1000)


linear_insertion_time = timeit.timeit(lambda: linear_search_insertion_sorted(unsorted_list, target), number=1)
linear_search_bubble_time = timeit.timeit(lambda: linear_search_bubble_sorted(unsorted_list, target), number=1)
binary_search_insertion_time = timeit.timeit(lambda: binary_search_insertion_sorted(unsorted_list, target), number=1)
binary_search_bubble_time = timeit.timeit(lambda: binary_search_bubble_sorted(unsorted_list, target), number=1)
"""

sizes = [10000, 20000, 40000]
num_of_tests = 5

for size in sizes:  # run it for each data number
    
    # total time vars
    total_linear_insertion = 0
    total_linear_bubble = 0
    total_binary_insertion = 0
    total_binary_bubble = 0

    for i in range(num_of_tests):   # run each test multiple times to remove randomness

        unsorted_list = [random.randint(1, 100000) for _ in range(size)]
        target = random.choice(unsorted_list)
        
        # note that we make copies of the list - otherwise when one function runs it will sort it for the rest of them
        linear_insertion_time = timeit.timeit(lambda: linear_search_insertion_sorted(unsorted_list.copy(), target), number=1)
        linear_search_bubble_time = timeit.timeit(lambda: linear_search_bubble_sorted(unsorted_list.copy(), target), number=1)
        binary_search_insertion_time = timeit.timeit(lambda: binary_search_insertion_sorted(unsorted_list.copy(), target), number=1)
        binary_search_bubble_time = timeit.timeit(lambda: binary_search_bubble_sorted(unsorted_list.copy(), target), number=1)

        total_linear_insertion += linear_insertion_time
        total_linear_bubble += linear_search_bubble_time
        total_binary_insertion += binary_search_insertion_time
        total_binary_bubble += binary_search_bubble_time

    # average out the results
    avg_linear_insertion = total_linear_insertion / num_of_tests
    avg_linear_bubble = total_linear_bubble / num_of_tests
    avg_binary_insertion = total_binary_insertion / num_of_tests
    avg_binary_bubble = total_binary_bubble / num_of_tests

    print(f"\nResults for list size {size}")
    print(f"Linear Search + Insertion Sort Average Time: {avg_linear_insertion:.6f} seconds")
    print(f"Linear Search + Bubble Sort Average Time: {avg_linear_bubble:.6f} seconds")
    print(f"Binary Search + Insertion Sort Average Time: {avg_binary_insertion:.6f} seconds")
    print(f"Binary Search + Bubble Sort Average Time: {avg_binary_bubble:.6f} seconds")


#print(f"Binary Search (With Sorting) Execution Time: {binary_time:.6f} seconds")
#print(f"Linear Search Execution Time: {linear_time:.6f} seconds")







# One takeaway here is that the most efficient
# algorithm on paper isn't always the most 
# efficient in practice. If binary search requires
# sorted data, and we only have unsorted data,
# then we'll need to factor in the efficiency
# of the sorting algorithm as well when choosing
# a searching algorithm. In this case, linear search
# might win out simply because you don't need to 
# sort the list before searching.
