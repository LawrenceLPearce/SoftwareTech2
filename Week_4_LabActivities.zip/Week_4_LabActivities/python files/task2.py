import timeit
import random


# LINEAR SEARCH

# To review, linear search involves sequentially checking every element
# in a collection until the desired value is found.
def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i
        
    return -1

test = range(1000000)
print(linear_search(test, 99999))
print(linear_search(test, -999))


# BINARY SEARCH
# An alternative to linear search is binary search. Binary search can be more efficient than
# linear search, but with a few caveats.
# First, the algorithm is more complex (this tradeoff always exists), and second,
# it requires data to be sorted. If binary search is run on unsorted data, it
# can perform just as poorly as linear search and it may produce erroneous results.

def binary_search(array, target):

    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1

test = [1, 1, 1, 2, 3, 6, 9, 19, 555]
print(binary_search(test, 1))
print(binary_search(test, 555))

# Note another quirk of binary search is that it does not guarantee to return
# the first occurance of an element, just *some* occurance if that element does in fact appear.

# Comparing linear and binary search efficiency
# Generate a sorted list of integers for testing


sorted_list = list(range(100000000))

# Test cases
"""
target = random.randint(0, 999999)  # Random target value
linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)

print(f"Linear search execution time: {linear_time:.6f} seconds")
print(f"Binary search execution time: {binary_time:.6f} seconds")

# As we can see, for sorted data, binary search is orders of magnitude faster than
# linear search.

sorted_list = list(range(10000000))
"""

# get average time over multiple tests.
number_of_tests = 15
total_linear_time = 0
total_binary_time = 0

for i in range(number_of_tests):

    target = random.randint(0, 999999)

    linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
    binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)

    total_linear_time += linear_time
    total_binary_time += binary_time
print(f"Linear search average time: {(total_linear_time/number_of_tests):.6f} seconds")
print(f"Binary search average time: {(total_binary_time/number_of_tests):.6f} seconds")

