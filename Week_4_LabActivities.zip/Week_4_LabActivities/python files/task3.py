import timeit
import random
# SORTING ALGORITHMS
# Another major category of algorithm is the sorting algorithm. Sorting algorithms 
# are used to sort collections of elements into sorted order (such as numerical order for lists of numbers).


# BUBBLE SORT
def bubble_sort(arr):
    """
    Bubble Sort: A simple sorting algorithm that repeatedly steps through the list,
    compares adjacent elements, and swaps them if they are in the wrong order.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):

            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break

    return arr

# Example usage:
unsorted_list = [64, 25, 12, 22, 11]
sorted_list = bubble_sort(unsorted_list)
print("Sorted array:", sorted_list)



# INSERTION SORT
def insertion_sort(arr):
    """
    Insertion Sort: A simple sorting algorithm that builds the final sorted
    array one item at a time. It takes each element from the input list and
    inserts it into its correct position in the sorted part of the array.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr

# Example usage:
unsorted_list = [64, 25, 12, 22, 11]
sorted_list = insertion_sort(unsorted_list)
print("Sorted array:", sorted_list)

# Comparing bubble sort and insertion sort
# Generate a random unsorted list of 1000 integers
#

number_of_tests = 5
total_bubble_sort_time = 0
total_insert_sort_time = 0
for i in range(number_of_tests):

    unsorted_list = [random.randint(1, 1000) for _ in range(40000)]

# Measure and compare the runtimes of Bubble Sort and Insertion Sort
    bubble_sort_time = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=1)
    insertion_sort_time = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=1)
    
    total_bubble_sort_time+=bubble_sort_time
    total_insert_sort_time+=insertion_sort_time

    print(f"Bubble Sort Execution Time: {bubble_sort_time:.6f} seconds")
    print(f"Insertion Sort Execution Time: {insertion_sort_time:.6f} seconds")
print(f"Average Bubble Sort Execution Time: {(total_bubble_sort_time/number_of_tests):.6f} seconds")
print(f"Average Insertion Sort Execution Time: {(total_insert_sort_time/number_of_tests):.6f} seconds")

# Both bubble sort and insertion sort are quite inefficient, since their runtime scales
# exponentially with the number of elements. However, they are useful for demonstrating
# the principles of sorting algorithms. 
